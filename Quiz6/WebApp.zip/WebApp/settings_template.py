server = 'EnterServerURL'
database = 'EnterDBName'
username = 'EnterUserName'
password = 'EnterPassword'   
driver= 'Enter Driver'

mapQuest_key = 'EnterKey'
mapQuest_url = 'http://open.mapquestapi.com/geocoding/v1/address?key='



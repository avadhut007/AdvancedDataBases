server = 'asg1.database.windows.net'
database = 'asg1DB'
username = 'firstUser'
password = 'SaveYourDB123'   
driver= '{ODBC Driver 17 for SQL Server}'

mapQuest_key = 'b0HyfKesjA9DnqNox19MAAWmjb18rdwH'
mapQuest_url = 'http://open.mapquestapi.com/geocoding/v1/address?key='


